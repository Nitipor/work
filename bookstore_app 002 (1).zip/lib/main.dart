import 'package:flutter/material.dart';
import 'helpers/database_helper.dart';
import 'models/book.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ร้านหนังสือ',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: BookListPage(),
    );
  }
}

class BookListPage extends StatefulWidget {
  @override
  _BookListPageState createState() => _BookListPageState();
}

class _BookListPageState extends State<BookListPage> {
  late DatabaseHelper dbHelper;
  List<Book> books = [];

  @override
  void initState() {
    super.initState();
    dbHelper = DatabaseHelper();
    _refreshBookList();
  }

  void _refreshBookList() async {
    List<Book> x = await dbHelper.getBooks();
    setState(() {
      books = x;
    });
  }

  void _showForm([Book? book]) {
    final _formKey = GlobalKey<FormState>();
    String title = book?.title ?? '';
    String author = book?.author ?? '';
    double price = book?.price ?? 0.0;

    showModalBottomSheet(
      context: context,
      builder: (_) {
        return Padding(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  TextFormField(
                    initialValue: title,
                    decoration: InputDecoration(labelText: 'ชื่อหนังสือ'),
                    validator: (value) => value!.isEmpty ? 'กรุณากรอกชื่อหนังสือ' : null,
                    onSaved: (value) => title = value!,
                  ),
                  TextFormField(
                    initialValue: author,
                    decoration: InputDecoration(labelText: 'ผู้แต่ง'),
                    validator: (value) => value!.isEmpty ? 'กรุณากรอกชื่อผู้แต่ง' : null,
                    onSaved: (value) => author = value!,
                  ),
                  TextFormField(
                    initialValue: price != 0.0 ? price.toString() : '',
                    decoration: InputDecoration(labelText: 'ราคา'),
                    keyboardType: TextInputType.number,
                    validator: (value) => value!.isEmpty ? 'กรุณากรอกราคา' : null,
                    onSaved: (value) => price = double.parse(value!),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    child: Text(book == null ? 'เพิ่ม' : 'แก้ไข'),
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();

                        if (book == null) {
                          await dbHelper.insertBook(
                            Book(title: title, author: author, price: price),
                          );
                        } else {
                          await dbHelper.updateBook(
                            Book(id: book.id, title: title, author: author, price: price),
                          );
                        }
                        _refreshBookList();
                        Navigator.of(context).pop();
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('รายการหนังสือ')),
      body: ListView.builder(
        itemCount: books.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(books[index].title),
              subtitle: Text('ผู้แต่ง: ${books[index].author}'),
              trailing: Text('฿${books[index].price.toStringAsFixed(2)}'),
              onTap: () => _showForm(books[index]),
              onLongPress: () {
                dbHelper.deleteBook(books[index].id!);
                _refreshBookList();
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () => _showForm(),
      ),
    );
  }
}
